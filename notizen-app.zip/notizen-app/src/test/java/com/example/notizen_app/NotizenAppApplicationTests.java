package com.example.notizen_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotizenAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
